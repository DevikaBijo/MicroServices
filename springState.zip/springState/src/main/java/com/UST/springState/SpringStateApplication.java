package com.UST.springState;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringStateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringStateApplication.class, args);
	}

}
